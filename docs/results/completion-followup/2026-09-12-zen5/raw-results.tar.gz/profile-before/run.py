from pathlib import Path
import os,subprocess,json,time
root=Path('/srv/mithril-sigverify-streaming-20260912');out=root/'completion-followup-20260912/profile-before';go='/usr/local/go/bin/go'
env=os.environ|{'PATH':'/usr/local/go/bin:'+os.environ.get('PATH',''),'GOMAXPROCS':'8','MITHRIL_SIGVERIFY_FLOW_BACKEND':'r51','MITHRIL_SIGVERIFY_FLOW_COUNT':'33760'}
def run(name,args,timeout=180):
 print('START',name,flush=True);begin=time.time()
 with (out/(name+'.txt')).open('w') as log:
  p=subprocess.run(args,cwd=root/'source',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 with (out/'commands.jsonl').open('a') as record:record.write(json.dumps({'name':name,'args':args,'seconds':time.time()-begin,'exit_code':p.returncode})+'\n')
 if p.returncode: print((out/(name+'.txt')).read_text()[-9000:],flush=True);raise RuntimeError(name)
 print('PASS',name,flush=True)
run('build',['nice','-n','10',go,'test','-overlay='+str(out/'overlay.json'),'-c','-p','2','-o',str(out/'diagnostic.test'),'./pkg/turbine'])
base=['nice','-n','10','taskset','-c','0-7',str(out/'diagnostic.test'),'-test.run=^$','-test.timeout=150s']
bench='^BenchmarkEntryPrefetchAssembly$/^generated_.*$/^workers_2$/^target_8$/^tip_200ms$/^overlap_on$'
run('stages',base+['-test.bench='+bench,'-test.benchtime=8x','-test.count=3'])
bench='^BenchmarkEntryPrefetchAssembly$/^generated_1232B$/^workers_2$/^target_8$/^tip_200ms$/^overlap_on$'
run('profile-run',base+['-test.bench='+bench,'-test.benchtime=50x','-test.count=1','-test.cpuprofile='+str(out/'cpu.pprof'),'-test.memprofile='+str(out/'memory.pprof')])
run('cpu-completion',[go,'tool','pprof','-top','-nodecount=25','-tagfocus=stage=completion',str(out/'diagnostic.test'),str(out/'cpu.pprof')])
run('alloc-completion',[go,'tool','pprof','-top','-alloc_space','-nodecount=20','-focus=processCompletion',str(out/'diagnostic.test'),str(out/'memory.pprof')])
run('cpu-entry-lines',[go,'tool','pprof','-list=decodeEntriesAndAlpenglowMarkersFromDataShreds','-tagfocus=stage=completion',str(out/'diagnostic.test'),str(out/'cpu.pprof')])
print('COMPLETE',flush=True)
