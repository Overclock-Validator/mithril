from pathlib import Path
import json,subprocess,hashlib
repo=Path('/Users/nikolashayes/Desktop/programming/Codex/mithril-planner-pr257-trial-20260912')
out=Path(__file__).resolve().parent
remote='/srv/mithril-sigverify-streaming-20260912'
def rep(s,old,new):
 assert old in s,old
 return s.replace(old,new,1)
s=(repo/'pkg/turbine/assembler.go').read_text()
s=rep(s,'type processedSlotCompletion struct {','type processedSlotCompletion struct {\n diagnostics entryDecodeTimings')
s=rep(s,'roots: roots, err: err, timings: timings}', 'roots: roots, err: err, timings: timings, diagnostics: decodeTimings}')
s=rep(s,'entries, parentInfo, footer, err := decodeEntriesAndAlpenglowMarkersFromDataShreds(s.orderedShreds(), timings)', '''orderStart := time.Now()
 ordered := s.orderedShreds()
 if timings != nil { timings.order = time.Since(orderStart) }
 entryStart := time.Now()
 entries, parentInfo, footer, err := decodeEntriesAndAlpenglowMarkersFromDataShreds(ordered, timings)
 if timings != nil { timings.entryDecode = time.Since(entryStart) }''')
s=rep(s,'blk := BlockFromEntries(s.slot, effectiveParentSlot, entries)', 'buildStart := time.Now()\n blk := BlockFromEntries(s.slot, effectiveParentSlot, entries)')
s=rep(s,'roots, err := s.optionalFECSetMerkleRoots()', '''if timings != nil { timings.blockBuild = time.Since(buildStart) }
 rootsStart := time.Now()
 roots, err := s.optionalFECSetMerkleRoots()
 if timings != nil { timings.roots = time.Since(rootsStart) }''')
(out/'assembler.go').write_text(s)
s=(repo/'pkg/turbine/entries.go').read_text()
s=rep(s,'type entryDecodeTimings struct {','type entryDecodeTimings struct {\n order, entryDecode, blockBuild, roots, entrySort, reassemble, cacheCheck time.Duration')
pos=s.index('func decodeEntriesAndAlpenglowMarkersFromDataShreds(')
head,s=s[:pos],s[pos:]
s=rep(s,'sort.Slice(shreds, func(i, j int) bool {', 'sortStarted := time.Now()\n sort.Slice(shreds, func(i, j int) bool {')
s=rep(s,'var entryBatches []*prefetchedShredBatch','if timings != nil { timings.entrySort = time.Since(sortStarted) }\n var reassemblyStarted time.Time\n var entryBatches []*prefetchedShredBatch')
s=rep(s,'if !haveBatch {\n\t\t\tbatchStart', 'if !haveBatch {\n reassemblyStarted = time.Now()\n\t\t\tbatchStart')
s=rep(s,'var batch *prefetchedShredBatch', 'if timings != nil { timings.reassemble += time.Since(reassemblyStarted) }\n cacheStarted := time.Now()\n var batch *prefetchedShredBatch')
s=rep(s,'if batch == nil {','if timings != nil { timings.cacheCheck += time.Since(cacheStarted) }\n if batch == nil {')
(out/'entries.go').write_text(head+s)
s=(repo/'pkg/turbine/entry_prefetch_benchmark_test.go').read_text()
s=rep(s,'"fmt"','"fmt"\n "runtime/pprof"')
s=rep(s,'var cpu float64','var cpu float64\n diagnosticSums := make(map[string]time.Duration)')
s=rep(s,'processed := a.processCompletion(context.Background(), work)', '''var processed processedSlotCompletion
 pprof.Do(context.Background(), pprof.Labels("stage", "completion"), func(ctx context.Context) { processed = a.processCompletion(ctx, work) })''')
s=rep(s,'ready = append(ready, processed.timings.FullToReady)', '''d := processed.diagnostics
 for name, duration := range map[string]time.Duration{"order":d.order,"entry_decode":d.entryDecode,"block_build":d.blockBuild,"roots":d.roots,"entry_sort":d.entrySort,"reassemble":d.reassemble,"cache_check":d.cacheCheck,"full_ready":processed.timings.FullToReady} { diagnosticSums[name]+=duration }
 ready = append(ready, processed.timings.FullToReady)''')
s=rep(s,'b.ReportMetric(cpu*1000/float64(b.N), "cpu-ms/block")','''for name, duration := range diagnosticSums { b.ReportMetric(float64(duration)/float64(time.Millisecond)/float64(b.N), "diag_"+name+"-ms/block") }
 b.ReportMetric(cpu*1000/float64(b.N), "cpu-ms/block")''')
(out/'entry_prefetch_benchmark_test.go').write_text(s)
files=['assembler.go','entries.go','entry_prefetch_benchmark_test.go']
subprocess.run(['gofmt','-w',*[str(out/p) for p in files]],check=True)
(out/'overlay.json').write_text(json.dumps({'Replace':{remote+'/source/pkg/turbine/'+p:remote+'/completion-followup-20260912/profile-before/'+p for p in files}},indent=2))
(out/'method.json').write_text(json.dumps({'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'files':{p:hashlib.sha256((out/p).read_bytes()).hexdigest() for p in files},'description':'Diagnostic Go overlays only; no repository or running validator changes.'},indent=2))
