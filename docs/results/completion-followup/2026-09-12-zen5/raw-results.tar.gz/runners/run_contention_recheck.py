"""Compare execution contention of 8/32/64-signature jobs on eight shared cores.

Separate processes: this excludes shared Go scheduler/heap effects and full replay.
"""
from pathlib import Path
import json, os, random, subprocess, time

root = Path('/srv/mithril-sigverify-streaming-20260912')
out = root/'completion-followup-20260912'
dest = out/'contention-recheck'
dest.mkdir(exist_ok=False)
env = os.environ | {'GOMAXPROCS':'8'}
for key in list(env):
    if key.startswith('MITHRIL_SIGVERIFY_FLOW_'): del env[key]
def parse(path):
    rows = []
    for line in path.read_text().splitlines():
        if not line.startswith('Benchmark'): continue
        f = line.split()
        rows.append({'name':f[0], 'iterations':int(f[1]), **{f[i+1]:float(f[i]) for i in range(2,len(f),2)}})
    assert len(rows) == 1, (path, rows)
    return rows[0]
probe_command = ['nice','-n','10','taskset','-c','0-7',str(root/'bin/replay.test'),'-test.run=^$','-test.bench=^BenchmarkLoadAndExecuteTransferResultMode$/^lean$','-test.benchtime=500ms','-test.count=1','-test.timeout=120s']
def probe(path):
    with path.open('w') as log:
        subprocess.run(probe_command, env=env, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=120)
    return parse(path)
records = []
conditions = [(job,mode) for job in [8,32,64] for mode in ['catchup','tip_200ms_overlap']]
rng = random.Random(12)
for sample in range(1):
    order = conditions.copy(); rng.shuffle(order)
    for job,mode in order:
        name = f'sample-{sample+4}-jobs{job}-{mode}'
        print('START', name, flush=True)
        folder = dest/name; folder.mkdir()
        baseline = probe(folder/'execution-baseline.txt')
        ready, start = folder/'ready', folder/'start'
        load_env = env | {'MITHRIL_SIGVERIFY_FLOW_BACKEND':'r51','MITHRIL_SIGVERIFY_FLOW_FIXTURES':'/srv/mithril-planner-pr257-trial-20260912/fixtures','MITHRIL_SIGVERIFY_FLOW_READY':str(ready),'MITHRIL_SIGVERIFY_FLOW_START':str(start)}
        blocks = 64 if mode == 'catchup' else 24
        command = ['nice','-n','10','taskset','-c','0-7',str(out/'variants'/f'roots_jobs{job}'/'turbine.test'),'-test.run=^$','-test.bench=^BenchmarkTransactionVerificationFlow$/^captured_2622581$/^workers_2$/^target_8$/^'+mode+'$',f'-test.benchtime={blocks}x','-test.count=1','-test.timeout=120s']
        path = folder/'signature-load.txt'
        with path.open('w') as log:
            process = subprocess.Popen(command, env=load_env, stdout=log, stderr=subprocess.STDOUT)
            try:
                deadline = time.monotonic()+30
                while not ready.exists():
                    if process.poll() is not None: raise RuntimeError(path.read_text())
                    if time.monotonic()>deadline: raise TimeoutError(name)
                    time.sleep(.01)
                start.touch(); time.sleep(.4)
                if process.poll() is not None: raise RuntimeError('load ended before probe')
                concurrent = probe(folder/'execution-concurrent.txt')
                if process.poll() is not None: raise RuntimeError('load ended during probe')
                assert process.wait(timeout=120) == 0, path.read_text()
            finally:
                if process.poll() is None:
                    process.terminate()
                    try: process.wait(timeout=5)
                    except subprocess.TimeoutExpired: process.kill(); process.wait()
        ratio = concurrent['ns/op']/baseline['ns/op']
        records.append({'sample':sample+4,'job_signatures':job,'mode':mode,'baseline':baseline,'concurrent':concurrent,'execution_slowdown_ratio':ratio,'load':parse(path),'load_command':command})
        (dest/'comparison.json').write_text(json.dumps({'description':__doc__,'probe_command':probe_command,'records':records},indent=2)+'\n')
        print('PASS', name, 'execution ratio', round(ratio,4), flush=True)
print('COMPLETE', flush=True)
