from pathlib import Path
import runpy
p=Path(__file__).resolve().parent
runpy.run_path(str(p/"run_contention_recheck.py"), run_name="__main__")
runpy.run_path(str(p/"run_final.py"), run_name="__main__")
