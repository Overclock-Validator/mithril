from pathlib import Path
import hashlib, json, os, subprocess, time

root=Path('/srv/mithril-sigverify-streaming-20260912');out=root/'completion-followup-20260912';go='/usr/local/go/bin/go'
dest=out/'final-results';dest.mkdir(exist_ok=False)
env=os.environ|{'PATH':'/usr/local/go/bin:'+os.environ.get('PATH',''),'GOMAXPROCS':'8','CGO_ENABLED':'1','GOAMD64':'v1','MITHRIL_SIGVERIFY_FLOW_BACKEND':'r51','MITHRIL_SIGVERIFY_FLOW_COUNT':'33760'}
def run(name,args,timeout=240):
 print('START',name,flush=True);start=time.time()
 with (dest/(name+'.txt')).open('w') as log:p=subprocess.run(args,cwd=root/'source',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 with (dest/'commands.jsonl').open('a') as log:log.write(json.dumps({'name':name,'args':args,'seconds':time.time()-start,'exit_code':p.returncode})+'\n')
 if p.returncode:print((dest/(name+'.txt')).read_text()[-8000:],flush=True);raise RuntimeError(name)
 print('PASS',name,flush=True)
for variant in ['final','profile-final']:
 for file,digest in json.loads((out/variant/'method.json').read_text())['files'].items():assert hashlib.sha256((out/variant/file).read_bytes()).hexdigest()==digest
overlay='-overlay='+str(out/'final/overlay.json')
run('native-unit',['nice','-n','10',go,'test',overlay,'-p','2','./pkg/turbine','./pkg/replay','./cmd/mithril/node','-count=1'])
run('native-race',['nice','-n','10',go,'test',overlay,'-race','-p','2','./pkg/turbine','-count=1'])
run('native-vet',['nice','-n','10',go,'vet',overlay,'./pkg/turbine'])
run('build-final',['nice','-n','10',go,'test',overlay,'-c','-p','2','-o',str(out/'final/turbine.test'),'./pkg/turbine'])
binary={'baseline':out/'variants/baseline/turbine.test','final':out/'final/turbine.test'}
(dest/'binaries.json').write_text(json.dumps({k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in binary.items()},indent=2))
bench='^BenchmarkEntryPrefetchAssembly$/^generated_.*$/^workers_2$/^target_8$/.*'
for sample in range(6):
 for name in (['baseline','final'] if sample%2==0 else ['final','baseline']):
  run(f'sample-{sample+1}-{name}',['nice','-n','10','taskset','-c','0-7',str(binary[name]),'-test.run=^$','-test.bench='+bench,'-test.benchtime=5x','-test.count=1','-test.timeout=180s'])
run('build-profile',['nice','-n','10',go,'test','-overlay='+str(out/'profile-final/overlay.json'),'-c','-p','2','-o',str(out/'profile-final/turbine.test'),'./pkg/turbine'])
bench='^BenchmarkEntryPrefetchAssembly$/^generated_1232B$/^workers_2$/^target_8$/^tip_200ms$/^overlap_on$'
run('profile-final',['nice','-n','10','taskset','-c','0-7',str(out/'profile-final/turbine.test'),'-test.run=^$','-test.bench='+bench,'-test.benchtime=30x','-test.count=1','-test.timeout=180s','-test.cpuprofile='+str(out/'profile-final/cpu.pprof')])
run('profile-cpu',[go,'tool','pprof','-top','-nodecount=20','-tagfocus=stage=completion',str(out/'profile-final/turbine.test'),str(out/'profile-final/cpu.pprof')])
run('service-status',['systemctl','show','mithril-alpenglow-pr259.service','--property=ActiveState,SubState,MainPID,ExecMainStartTimestamp'])
print('COMPLETE',flush=True)
