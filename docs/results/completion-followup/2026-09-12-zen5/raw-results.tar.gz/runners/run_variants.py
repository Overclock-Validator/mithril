from pathlib import Path
import hashlib, json, os, subprocess, time

root = Path('/srv/mithril-sigverify-streaming-20260912')
out = root/'completion-followup-20260912'
results = out/'results'
results.mkdir(exist_ok=False)
go = '/usr/local/go/bin/go'
env = os.environ | {'PATH':'/usr/local/go/bin:'+os.environ.get('PATH',''), 'GOMAXPROCS':'8', 'CGO_ENABLED':'1', 'GOAMD64':'v1', 'MITHRIL_SIGVERIFY_FLOW_BACKEND':'r51', 'MITHRIL_SIGVERIFY_FLOW_COUNT':'33760'}
def run(name, args, timeout=240):
    print('START', name, flush=True)
    started = time.time()
    with (results/(name+'.txt')).open('w') as log:
        p = subprocess.run(args, cwd=root/'source', env=env, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
    with (results/'commands.jsonl').open('a') as log:
        log.write(json.dumps({'name':name, 'args':args, 'seconds':time.time()-started, 'exit_code':p.returncode})+'\n')
    if p.returncode:
        print((results/(name+'.txt')).read_text()[-8000:], flush=True)
        raise RuntimeError(name)
    print('PASS', name, flush=True)
method = json.loads((out/'method.json').read_text())
names = list(method['variants'])
for name, files in method['variants'].items():
    for file, digest in files.items():
        assert hashlib.sha256((out/'variants'/name/file).read_bytes()).hexdigest() == digest
    run('build-'+name, ['nice','-n','10',go,'test','-overlay='+str(out/'variants'/name/'overlay.json'),'-c','-p','2','-o',str(out/'variants'/name/'turbine.test'),'./pkg/turbine'])
(results/'binaries.json').write_text(json.dumps({name:hashlib.sha256((out/'variants'/name/'turbine.test').read_bytes()).hexdigest() for name in names}, indent=2))
assembly = '^BenchmarkEntryPrefetchAssembly$/^generated_.*$/^workers_2$/^target_8$/.*'
pool = '^BenchmarkTransactionVerificationFlow$/^generated_.*$/^workers_2$/^target_8$/^(catchup|tip_200ms_overlap|sparse_4tx_200ms_overlap)$'
for sample in range(4):
    order = names[sample:]+names[:sample]
    if sample%2: order.reverse()
    for name in order:
        run(f'assembly-{sample+1}-{name}', ['nice','-n','10','taskset','-c','0-7',str(out/'variants'/name/'turbine.test'),'-test.run=^$','-test.bench='+assembly,'-test.benchtime=5x','-test.count=1','-test.timeout=180s'])
    for name in ['roots_jobs8','roots_jobs32','roots_jobs64'][sample%3:]+['roots_jobs8','roots_jobs32','roots_jobs64'][:sample%3]:
        run(f'pool-{sample+1}-{name}', ['nice','-n','10','taskset','-c','0-7',str(out/'variants'/name/'turbine.test'),'-test.run=^$','-test.bench='+pool,'-test.benchtime=5x','-test.count=1','-test.timeout=180s'])
print('COMPLETE', flush=True)
