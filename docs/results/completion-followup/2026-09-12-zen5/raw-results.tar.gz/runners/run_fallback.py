from pathlib import Path
import json,os,subprocess,time
root=Path('/srv/mithril-sigverify-streaming-20260912');out=root/'completion-followup-20260912';dest=out/'fallback-results';dest.mkdir(exist_ok=False)
env=os.environ|{'PATH':'/usr/local/go/bin:'+os.environ.get('PATH',''),'GOMAXPROCS':'8','MITHRIL_SIGVERIFY_FLOW_BACKEND':'r51','MITHRIL_SIGVERIFY_FLOW_COUNT':'33760','CGO_ENABLED':'1','GOAMD64':'v1'}
def run(name,args):
 print('START',name,flush=True);start=time.time()
 with (dest/(name+'.txt')).open('w') as log:p=subprocess.run(args,cwd=root/'source',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 with (dest/'commands.jsonl').open('a') as log:log.write(json.dumps({'name':name,'args':args,'seconds':time.time()-start,'exit_code':p.returncode})+'\n')
 if p.returncode:print((dest/(name+'.txt')).read_text()[-8000:],flush=True);raise RuntimeError(name)
 print('PASS',name,flush=True)
run('build',['nice','-n','10','/usr/local/go/bin/go','test','-overlay='+str(out/'fallback/overlay.json'),'-c','-p','2','-o',str(out/'fallback/turbine.test'),'./pkg/turbine'])
binary={'baseline':out/'variants/baseline/turbine.test','fallback':out/'fallback/turbine.test'}
bench='^BenchmarkEntryPrefetchAssembly$/^generated_.*$/^workers_2$/^target_8$/^catchup$/.*'
for sample in range(3):
 for name in (['baseline','fallback'] if sample%2==0 else ['fallback','baseline']):
  run(f'sample-{sample+1}-{name}',['nice','-n','10','taskset','-c','0-7',str(binary[name]),'-test.run=^$','-test.bench='+bench,'-test.benchtime=5x','-test.count=1','-test.timeout=120s'])
print('COMPLETE',flush=True)
