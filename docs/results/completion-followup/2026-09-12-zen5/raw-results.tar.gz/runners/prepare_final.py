from pathlib import Path
import hashlib, json, subprocess

repo = Path('/Users/nikolashayes/Desktop/programming/Codex/mithril-planner-pr257-trial-20260912')
out = Path(__file__).resolve().parent
remote = '/srv/mithril-sigverify-streaming-20260912'
names = ['entries.go','assembler.go','sigcache.go','receiver.go','fec_root_cache.go','transaction_verifier.go','entry_prefetch_benchmark_test.go','entries_direct_compare_test.go','completion_order_root_test.go','transaction_job_groups_test.go','transaction_verifier_test.go']
files = {n:(repo/'pkg/turbine'/n).read_text() for n in names}
def save(name, contents):
    dest = out/name; dest.mkdir(exist_ok=False)
    for file,s in contents.items(): (dest/file).write_text(s)
    subprocess.run(['gofmt','-w',*[str(dest/f) for f in contents]],check=True)
    (dest/'overlay.json').write_text(json.dumps({'Replace':{remote+'/source/pkg/turbine/'+f:remote+'/completion-followup-20260912/'+name+'/'+f for f in contents}},indent=2))
    (dest/'method.json').write_text(json.dumps({'base':'e063695f5b22a68990007c99c7dc7b64eef5568e','files':{f:hashlib.sha256((dest/f).read_bytes()).hexdigest() for f in contents}},indent=2)+'\n')
save('final',files)
diag = files.copy()
def rep(s, old, new):
    assert old in s, old
    return s.replace(old,new,1)
s = diag['assembler.go']
s = rep(s,'type processedSlotCompletion struct {','type processedSlotCompletion struct {\n diagnostics entryDecodeTimings')
s = rep(s,'roots: roots, err: err, timings: timings}', 'roots: roots, err: err, timings: timings, diagnostics: decodeTimings}')
s = rep(s,'entries, parentInfo, footer, err := decodeEntriesFromOrderedDataShreds(s.orderedShreds(), timings)', '''orderStart := time.Now()
 ordered := s.orderedShreds()
 if timings != nil { timings.diagOrder = time.Since(orderStart) }
 entryStart := time.Now()
 entries, parentInfo, footer, err := decodeEntriesFromOrderedDataShreds(ordered, timings)
 if timings != nil { timings.diagDecode = time.Since(entryStart) }''')
s = rep(s,'blk := BlockFromEntries(s.slot, effectiveParentSlot, entries)', 'buildStart := time.Now()\n blk := BlockFromEntries(s.slot, effectiveParentSlot, entries)')
s = rep(s,'roots, err := s.optionalFECSetMerkleRoots()', '''if timings != nil { timings.diagBuild = time.Since(buildStart) }
 rootsStart := time.Now()
 roots, err := s.optionalFECSetMerkleRoots()
 if timings != nil { timings.diagRoots = time.Since(rootsStart) }''')
diag['assembler.go']=s
diag['entries.go']=rep(diag['entries.go'],'type entryDecodeTimings struct {','type entryDecodeTimings struct {\n diagOrder, diagDecode, diagBuild, diagRoots time.Duration')
s=diag['entry_prefetch_benchmark_test.go']
s=rep(s,'"fmt"','"fmt"\n "runtime/pprof"')
s=rep(s,'var cpu float64','var cpu float64\n diagnosticSums := make(map[string]time.Duration)')
s=rep(s,'processed := a.processCompletion(context.Background(), work)', '''var processed processedSlotCompletion
 pprof.Do(context.Background(), pprof.Labels("stage", "completion"), func(ctx context.Context) { processed = a.processCompletion(ctx, work) })''')
s=rep(s,'ready = append(ready, processed.timings.FullToReady)', '''d := processed.diagnostics
 for name, duration := range map[string]time.Duration{"order":d.diagOrder,"entry_decode":d.diagDecode,"block_build":d.diagBuild,"roots":d.diagRoots,"full_ready":processed.timings.FullToReady} { diagnosticSums[name]+=duration }
 ready = append(ready, processed.timings.FullToReady)''')
s=rep(s,'b.ReportMetric(cpu*1000/float64(b.N), "cpu-ms/block")','''for name, duration := range diagnosticSums { b.ReportMetric(float64(duration)/float64(time.Millisecond)/float64(b.N), "diag_"+name+"-ms/block") }
 b.ReportMetric(cpu*1000/float64(b.N), "cpu-ms/block")''')
diag['entry_prefetch_benchmark_test.go']=s
save('profile-final',diag)
