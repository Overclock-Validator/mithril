from pathlib import Path
import hashlib, json, subprocess

repo = Path('/Users/nikolashayes/Desktop/programming/Codex/mithril-planner-pr257-trial-20260912')
out = Path(__file__).resolve().parent
remote = '/srv/mithril-sigverify-streaming-20260912'
base = 'e063695f5b22a68990007c99c7dc7b64eef5568e'
def original(name):
    return subprocess.check_output(['git', 'show', base+':pkg/turbine/'+name], cwd=repo, text=True)
def current(name):
    return (repo/'pkg/turbine'/name).read_text()
common = {'entry_prefetch_benchmark_test.go': current('entry_prefetch_benchmark_test.go')}
adapter = '''package turbine
import "github.com/gagliardetto/solana-go"
func (a *SlotAssembler) addShredFromWithRoot(s *Shred, repair bool, root *solana.Hash) (*slotCompletionWork, error) {
 return a.addShredFrom(s, repair)
}
'''
before = original('assembler.go')
start, end = before.index('func (s *slotState) orderedShreds()'), before.index('// decodeBlock performs')
now = current('assembler.go')
ordered = before[:start]+now[now.index('func (s *slotState) orderedShreds()'):now.index('// decodeBlock performs')]+before[end:]
ordered = ordered.replace('decodeEntriesAndAlpenglowMarkersFromDataShreds(s.orderedShreds(), timings)', 'decodeEntriesFromOrderedDataShreds(s.orderedShreds(), timings)')
variants = {
 'baseline': common | {'entries.go': original('entries.go'), 'benchmark_root_adapter_test.go': adapter},
 'ordering': common | {'entries.go': current('entries.go'), 'assembler.go': ordered, 'benchmark_root_adapter_test.go': adapter},
}
production = ['entries.go','assembler.go','sigcache.go','receiver.go','fec_root_cache.go','transaction_verifier.go']
for groups in (1,4,8):
    files = common | {name: current(name) for name in production}
    files['transaction_verifier.go'] = files['transaction_verifier.go'].replace('const defaultTransactionJobGroups = 1', 'const defaultTransactionJobGroups = '+str(groups))
    variants['roots_jobs'+str(groups*8)] = files
method = {'baseline_commit': base, 'description': 'Common authenticated-root handoff benchmark; baseline/ordering adapter ignores roots, reproducing old admission. Authentication remains outside timing. All native source overlays build against the unchanged isolated source.', 'variants':{}}
for name, files in variants.items():
    dest = out/'variants'/name
    dest.mkdir(parents=True, exist_ok=False)
    for filename, contents in files.items():
        (dest/filename).write_text(contents)
    subprocess.run(['gofmt','-w',*[str(dest/f) for f in files]], check=True)
    method['variants'][name] = {f: hashlib.sha256((dest/f).read_bytes()).hexdigest() for f in files}
    (dest/'overlay.json').write_text(json.dumps({'Replace':{remote+'/source/pkg/turbine/'+f:remote+'/completion-followup-20260912/variants/'+name+'/'+f for f in files}}, indent=2))
(out/'method.json').write_text(json.dumps(method, indent=2)+'\n')
